package com.example.tabbed_screen;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class Myadapter extends FragmentPagerAdapter {

    Context context;
    int total_tabs;
    public Myadapter(Context c, FragmentManager fm, int total_tabs) {
        super(fm, total_tabs);
        context =c;
        this.total_tabs=total_tabs;
    }


    @Override
    public Fragment getItem(int position) {
        switch (position)
        {
            case 0:
                Cricket cricket_tab = new Cricket();
                return cricket_tab;
            case 1:
                Football football_tab = new Football();
                return football_tab;
            case 2:
                Hockey hockey_tab = new Hockey();
                return hockey_tab;
            default:return null;
        }
    }


    @Override
    public int getCount() {
        return total_tabs;
    }
}